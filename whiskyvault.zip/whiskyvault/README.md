# WhiskyVault 🥃

A self-hosted, mobile-friendly whisky sample tracker. Log your tastings, write tasting notes, score drams, and manage your wishlist.

## Features

- Add whisky samples with distillery, region, age, ABV, and sample size
- Write tasting notes: nose, palate, finish
- Score each dram out of 100
- Attach a bottle/label photo
- Wishlist for whiskies you want to try
- Filter by region, search by name/distillery/tags
- Sort by date, score, or name
- Fully mobile-friendly

## Quick start with Docker

### Option 1: Docker Compose (recommended)

```bash
docker compose up -d
```

Then open http://localhost:3000 in your browser.

Your data (database + photos) is stored in `./whiskyvault-data/` on the host — safe to back up.

### Option 2: Docker run

```bash
docker build -t whiskyvault .
docker run -d \
  --name whiskyvault \
  --restart unless-stopped \
  -p 3000:3000 \
  -v $(pwd)/whiskyvault-data:/data \
  whiskyvault
```

### Updating

```bash
docker compose down
docker compose build --no-cache
docker compose up -d
```

## Run without Docker

Requires Node.js 18+.

```bash
npm install
npm start
```

Open http://localhost:3000.

## Data & backups

Everything is stored in the `/data` volume (mapped to `./whiskyvault-data/`):

- `whiskyvault.db` — SQLite database (all samples, notes, scores)
- `uploads/` — uploaded label/bottle photos

Back up the entire `whiskyvault-data/` folder to preserve all your data.

## Running behind a reverse proxy (nginx)

```nginx
server {
    listen 443 ssl;
    server_name whisky.yourdomain.com;

    ssl_certificate     /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    client_max_body_size 20M;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Port the server listens on |
| `NODE_ENV` | `production` | Node environment |

## Tech stack

- **Backend**: Node.js + Express
- **Database**: SQLite (via better-sqlite3)
- **File uploads**: Multer
- **Frontend**: Vanilla JS + HTML/CSS (no framework, fast on mobile)
