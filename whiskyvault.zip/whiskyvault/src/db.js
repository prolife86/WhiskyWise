const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbDir = path.join(__dirname, '../data');
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(path.join(dbDir, 'whiskyvault.db'));

db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    distillery TEXT,
    region TEXT,
    country TEXT,
    age INTEGER,
    is_nas INTEGER DEFAULT 0,
    abv REAL,
    sample_ml REAL,
    status TEXT DEFAULT 'wishlist',
    nose TEXT,
    palate TEXT,
    finish TEXT,
    score INTEGER,
    tags TEXT,
    photo TEXT,
    date_tasted TEXT,
    date_added TEXT DEFAULT (datetime('now')),
    notes TEXT
  );
`);

module.exports = db;
