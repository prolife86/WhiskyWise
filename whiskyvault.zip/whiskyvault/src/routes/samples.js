const express = require('express');
const router = express.Router();
const db = require('../db');
const upload = require('../middleware/upload');
const fs = require('fs');
const path = require('path');

// GET all samples with optional filters
router.get('/', (req, res) => {
  const { status, region, search, sort } = req.query;
  let query = 'SELECT * FROM samples WHERE 1=1';
  const params = [];

  if (status && status !== 'all') {
    query += ' AND status = ?'; params.push(status);
  }
  if (region) {
    query += ' AND region = ?'; params.push(region);
  }
  if (search) {
    query += ' AND (name LIKE ? OR distillery LIKE ? OR tags LIKE ?)';
    const s = `%${search}%`;
    params.push(s, s, s);
  }

  const sortMap = {
    date_desc: 'date_added DESC',
    date_asc: 'date_added ASC',
    score_desc: 'score DESC',
    score_asc: 'score ASC',
    name_asc: 'name ASC',
  };
  query += ` ORDER BY ${sortMap[sort] || 'date_added DESC'}`;

  try {
    const rows = db.prepare(query).all(...params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single sample
router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM samples WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  res.json(row);
});

// POST create sample
router.post('/', upload.single('photo'), (req, res) => {
  const {
    name, distillery, region, country, age, is_nas, abv, sample_ml,
    status, nose, palate, finish, score, tags, date_tasted, notes
  } = req.body;

  if (!name) return res.status(400).json({ error: 'Name is required' });

  const photo = req.file ? req.file.filename : null;

  const stmt = db.prepare(`
    INSERT INTO samples
      (name, distillery, region, country, age, is_nas, abv, sample_ml, status,
       nose, palate, finish, score, tags, photo, date_tasted, notes)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `);

  const result = stmt.run(
    name, distillery || null, region || null, country || null,
    age ? parseInt(age) : null, is_nas ? 1 : 0,
    abv ? parseFloat(abv) : null, sample_ml ? parseFloat(sample_ml) : null,
    status || 'wishlist', nose || null, palate || null, finish || null,
    score ? parseInt(score) : null, tags || null, photo,
    date_tasted || null, notes || null
  );

  const created = db.prepare('SELECT * FROM samples WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(created);
});

// PUT update sample
router.put('/:id', upload.single('photo'), (req, res) => {
  const existing = db.prepare('SELECT * FROM samples WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });

  const {
    name, distillery, region, country, age, is_nas, abv, sample_ml,
    status, nose, palate, finish, score, tags, date_tasted, notes,
    remove_photo
  } = req.body;

  let photo = existing.photo;
  if (req.file) {
    if (existing.photo) {
      const old = path.join(__dirname, '../../data/uploads', existing.photo);
      if (fs.existsSync(old)) fs.unlinkSync(old);
    }
    photo = req.file.filename;
  } else if (remove_photo === 'true' && existing.photo) {
    const old = path.join(__dirname, '../../data/uploads', existing.photo);
    if (fs.existsSync(old)) fs.unlinkSync(old);
    photo = null;
  }

  db.prepare(`
    UPDATE samples SET
      name=?, distillery=?, region=?, country=?, age=?, is_nas=?, abv=?, sample_ml=?,
      status=?, nose=?, palate=?, finish=?, score=?, tags=?, photo=?, date_tasted=?, notes=?
    WHERE id=?
  `).run(
    name || existing.name,
    distillery ?? existing.distillery,
    region ?? existing.region,
    country ?? existing.country,
    age ? parseInt(age) : existing.age,
    is_nas !== undefined ? (is_nas ? 1 : 0) : existing.is_nas,
    abv ? parseFloat(abv) : existing.abv,
    sample_ml ? parseFloat(sample_ml) : existing.sample_ml,
    status || existing.status,
    nose ?? existing.nose, palate ?? existing.palate, finish ?? existing.finish,
    score ? parseInt(score) : existing.score,
    tags ?? existing.tags, photo,
    date_tasted ?? existing.date_tasted,
    notes ?? existing.notes,
    req.params.id
  );

  res.json(db.prepare('SELECT * FROM samples WHERE id = ?').get(req.params.id));
});

// DELETE sample
router.delete('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM samples WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (existing.photo) {
    const p = path.join(__dirname, '../../data/uploads', existing.photo);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
  db.prepare('DELETE FROM samples WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// GET regions list
router.get('/meta/regions', (req, res) => {
  const rows = db.prepare("SELECT DISTINCT region FROM samples WHERE region IS NOT NULL ORDER BY region").all();
  res.json(rows.map(r => r.region));
});

// GET stats
router.get('/meta/stats', (req, res) => {
  const total = db.prepare("SELECT COUNT(*) as count FROM samples").get().count;
  const tasted = db.prepare("SELECT COUNT(*) as count FROM samples WHERE status='tasted'").get().count;
  const wishlist = db.prepare("SELECT COUNT(*) as count FROM samples WHERE status='wishlist'").get().count;
  const avgScore = db.prepare("SELECT ROUND(AVG(score),1) as avg FROM samples WHERE score IS NOT NULL AND status='tasted'").get().avg;
  res.json({ total, tasted, wishlist, avgScore });
});

module.exports = router;
