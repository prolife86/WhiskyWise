const API = '/api/samples';
let currentTab = 'collection';
let currentSample = null;
let searchTimeout = null;
let removePhoto = false;

const $ = id => document.getElementById(id);

async function fetchJSON(url, opts = {}) {
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

// --- Stats ---
async function loadStats() {
  try {
    const s = await fetchJSON(`${API}/meta/stats`);
    $('stat-tasted').textContent = s.tasted;
    $('stat-wishlist').textContent = s.wishlist;
    $('stat-avg').textContent = s.avgScore ?? '—';
  } catch {}
}

// --- Regions filter ---
async function loadRegions() {
  try {
    const regions = await fetchJSON(`${API}/meta/regions`);
    const sel = $('region-filter');
    sel.innerHTML = '<option value="">All regions</option>';
    regions.forEach(r => {
      const o = document.createElement('option');
      o.value = r; o.textContent = r;
      sel.appendChild(o);
    });
  } catch {}
}

// --- Grid ---
async function loadSamples() {
  const status = currentTab === 'wishlist' ? 'wishlist' : 'tasted';
  const search = $('search-input').value;
  const region = $('region-filter').value;
  const sort = $('sort-select').value;

  const params = new URLSearchParams({ status, sort });
  if (search) params.set('search', search);
  if (region) params.set('region', region);

  try {
    const samples = await fetchJSON(`${API}?${params}`);
    renderGrid(samples);
  } catch (e) {
    console.error(e);
  }
}

function renderGrid(samples) {
  const grid = $('sample-grid');
  const empty = $('empty-state');
  grid.innerHTML = '';

  if (!samples.length) {
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';

  samples.forEach(s => {
    const card = document.createElement('div');
    card.className = 'sample-card';
    card.innerHTML = `
      ${s.photo
        ? `<img class="card-photo" src="/uploads/${s.photo}" alt="${s.name}" loading="lazy" />`
        : `<div class="card-photo-placeholder">🥃</div>`}
      <div class="card-body">
        <div class="card-name">${esc(s.name)}</div>
        <div class="card-distillery">${esc(s.distillery || s.region || '—')}</div>
        <div class="card-meta">
          ${s.region ? `<span class="pill">${esc(s.region)}</span>` : ''}
          ${s.age ? `<span class="pill">${s.age}yr</span>` : (s.is_nas ? `<span class="pill">NAS</span>` : '')}
          ${s.abv ? `<span class="pill">${parseFloat(s.abv).toFixed(1)}%</span>` : ''}
          ${s.status === 'tasted' ? `<span class="pill pill-tasted">Tasted</span>` : `<span class="pill pill-amber">Wishlist</span>`}
          ${s.score ? `<span class="score-badge">${s.score}</span>` : ''}
        </div>
      </div>
    `;
    card.addEventListener('click', () => openDetail(s.id));
    grid.appendChild(card);
  });
}

function esc(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// --- Detail modal ---
async function openDetail(id) {
  try {
    const s = await fetchJSON(`${API}/${id}`);
    currentSample = s;
    $('detail-title').textContent = s.name;

    const body = $('detail-body');
    body.innerHTML = `
      ${s.photo ? `<img class="detail-photo" src="/uploads/${s.photo}" alt="${esc(s.name)}" />` : ''}
      <div class="detail-content">
        <div class="detail-meta">
          ${s.region ? `<span class="pill">${esc(s.region)}</span>` : ''}
          ${s.country ? `<span class="pill">${esc(s.country)}</span>` : ''}
          ${s.age ? `<span class="pill">${s.age} year old</span>` : (s.is_nas ? `<span class="pill">NAS</span>` : '')}
          ${s.abv ? `<span class="pill">${parseFloat(s.abv).toFixed(1)}% ABV</span>` : ''}
          ${s.sample_ml ? `<span class="pill">${s.sample_ml}ml</span>` : ''}
          ${s.status === 'tasted' ? `<span class="pill pill-tasted">Tasted</span>` : `<span class="pill pill-amber">Wishlist</span>`}
          ${s.score ? `<span class="detail-score">${s.score}<span style="font-size:14px;font-weight:400;color:var(--text3)">/100</span></span>` : ''}
        </div>
        ${s.distillery ? `<div class="detail-section"><div class="detail-section-label">Distillery</div><div class="detail-section-text">${esc(s.distillery)}</div></div>` : ''}
        ${s.nose ? `<div class="detail-section"><div class="detail-section-label">Nose</div><div class="detail-section-text">${esc(s.nose)}</div></div>` : ''}
        ${s.palate ? `<div class="detail-section"><div class="detail-section-label">Palate</div><div class="detail-section-text">${esc(s.palate)}</div></div>` : ''}
        ${s.finish ? `<div class="detail-section"><div class="detail-section-label">Finish</div><div class="detail-section-text">${esc(s.finish)}</div></div>` : ''}
        ${s.notes ? `<div class="detail-section"><div class="detail-section-label">Notes</div><div class="detail-section-text">${esc(s.notes)}</div></div>` : ''}
        ${s.tags ? `<div class="detail-section"><div class="detail-section-label">Tags</div><div class="detail-section-text">${esc(s.tags)}</div></div>` : ''}
        ${s.date_tasted ? `<div class="detail-section"><div class="detail-section-label">Date tasted</div><div class="detail-section-text">${s.date_tasted}</div></div>` : ''}
      </div>
    `;

    $('detail-overlay').style.display = 'flex';
  } catch (e) { console.error(e); }
}

$('detail-close').addEventListener('click', () => {
  $('detail-overlay').style.display = 'none';
  currentSample = null;
});
$('detail-overlay').addEventListener('click', e => {
  if (e.target === $('detail-overlay')) { $('detail-overlay').style.display = 'none'; currentSample = null; }
});
$('detail-edit').addEventListener('click', () => {
  $('detail-overlay').style.display = 'none';
  openEditModal(currentSample);
});

// --- Add / Edit modal ---
function openAddModal() {
  currentSample = null;
  $('modal-title').textContent = 'Add sample';
  $('sample-form').reset();
  $('form-id').value = '';
  $('score-display').textContent = '—';
  $('btn-delete').style.display = 'none';
  $('photo-preview').style.display = 'none';
  $('photo-label').style.display = 'flex';
  removePhoto = false;
  $('modal-overlay').style.display = 'flex';
}

function openEditModal(s) {
  $('modal-title').textContent = 'Edit sample';
  $('form-id').value = s.id;
  $('f-name').value = s.name || '';
  $('f-distillery').value = s.distillery || '';
  $('f-region').value = s.region || '';
  $('f-country').value = s.country || '';
  $('f-age').value = s.age || '';
  $('f-nas').checked = !!s.is_nas;
  $('f-abv').value = s.abv || '';
  $('f-ml').value = s.sample_ml || '';
  $('f-status').value = s.status || 'wishlist';
  $('f-nose').value = s.nose || '';
  $('f-palate').value = s.palate || '';
  $('f-finish').value = s.finish || '';
  $('f-notes').value = s.notes || '';
  $('f-score').value = s.score || 0;
  $('score-display').textContent = s.score || '—';
  $('f-tags').value = s.tags || '';
  $('f-date-tasted').value = s.date_tasted || '';
  $('btn-delete').style.display = 'inline-block';
  removePhoto = false;

  if (s.photo) {
    $('preview-img').src = `/uploads/${s.photo}`;
    $('photo-preview').style.display = 'block';
    $('photo-label').style.display = 'none';
  } else {
    $('photo-preview').style.display = 'none';
    $('photo-label').style.display = 'flex';
  }

  $('modal-overlay').style.display = 'flex';
}

$('btn-add').addEventListener('click', openAddModal);
$('modal-close').addEventListener('click', closeModal);
$('btn-cancel').addEventListener('click', closeModal);
$('modal-overlay').addEventListener('click', e => { if (e.target === $('modal-overlay')) closeModal(); });

function closeModal() {
  $('modal-overlay').style.display = 'none';
}

// Score slider
$('f-score').addEventListener('input', () => {
  const v = $('f-score').value;
  $('score-display').textContent = v == 0 ? '—' : v;
});

// Photo preview
$('f-photo').addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    $('preview-img').src = ev.target.result;
    $('photo-preview').style.display = 'block';
    $('photo-label').style.display = 'none';
    removePhoto = false;
  };
  reader.readAsDataURL(file);
});

$('photo-remove').addEventListener('click', () => {
  $('f-photo').value = '';
  $('preview-img').src = '';
  $('photo-preview').style.display = 'none';
  $('photo-label').style.display = 'flex';
  removePhoto = true;
});

// Form submit
$('sample-form').addEventListener('submit', async e => {
  e.preventDefault();
  const id = $('form-id').value;
  const formData = new FormData();

  formData.append('name', $('f-name').value);
  formData.append('distillery', $('f-distillery').value);
  formData.append('region', $('f-region').value);
  formData.append('country', $('f-country').value);
  formData.append('age', $('f-age').value);
  formData.append('is_nas', $('f-nas').checked ? '1' : '0');
  formData.append('abv', $('f-abv').value);
  formData.append('sample_ml', $('f-ml').value);
  formData.append('status', $('f-status').value);
  formData.append('nose', $('f-nose').value);
  formData.append('palate', $('f-palate').value);
  formData.append('finish', $('f-finish').value);
  formData.append('notes', $('f-notes').value);
  const score = $('f-score').value;
  formData.append('score', score == 0 ? '' : score);
  formData.append('tags', $('f-tags').value);
  formData.append('date_tasted', $('f-date-tasted').value);
  formData.append('remove_photo', removePhoto ? 'true' : 'false');

  const photoFile = $('f-photo').files[0];
  if (photoFile) formData.append('photo', photoFile);

  try {
    $('btn-save').textContent = 'Saving…';
    $('btn-save').disabled = true;

    if (id) {
      await fetch(`${API}/${id}`, { method: 'PUT', body: formData });
    } else {
      await fetch(API, { method: 'POST', body: formData });
    }

    closeModal();
    await Promise.all([loadSamples(), loadStats(), loadRegions()]);
  } catch (err) {
    alert('Error saving: ' + err.message);
  } finally {
    $('btn-save').textContent = 'Save';
    $('btn-save').disabled = false;
  }
});

// Delete
$('btn-delete').addEventListener('click', async () => {
  const id = $('form-id').value;
  if (!id || !confirm('Delete this sample?')) return;
  try {
    await fetch(`${API}/${id}`, { method: 'DELETE' });
    closeModal();
    await Promise.all([loadSamples(), loadStats(), loadRegions()]);
  } catch (err) {
    alert('Error deleting: ' + err.message);
  }
});

// Tabs
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentTab = btn.dataset.tab;
    loadSamples();
  });
});

// Search & filters
$('search-input').addEventListener('input', () => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(loadSamples, 300);
});
$('region-filter').addEventListener('change', loadSamples);
$('sort-select').addEventListener('change', loadSamples);

// Init
(async () => {
  await Promise.all([loadStats(), loadRegions(), loadSamples()]);
})();
